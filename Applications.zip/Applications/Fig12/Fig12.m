clear all;
clc;
load('result1.mat');
load('result2.mat');
load('result3.mat');

fig = figure('Units', 'pixels', 'Position', [100, 100, 1100, 900], 'Color', 'w');
left1 = 0.06; left2 = 0.53;
width = 0.41;
top_bottom = 0.57; top_height = 0.30;   
bot_bottom = 0.17; bot_height = 0.30;  
sizexy=12;
legendsize=12;
sizexy_in=12;
annHeight=0.02;
gap=0.001;

subplot(2, 2, 1);
Y_data = [result1(:,9)';result2(:,9)';result3(:,9)'];%single
X= [result1(:,4)';result2(:,4)';result3(:,4)'];
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.169,0.863,0.859 ];
lineStyles = {'-', '-', '-'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(X(i, :), Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('ratio', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left1, top_bottom, width, top_height]);
lgd = legend(lines, {'corner','long-border','short-border'}, 'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
hold off;
append_line_to_xlabel(gca, '(a) Variation in the ratio of single-movement across different I/O as a shape factor changes');

subplot(2, 2, 2);
A = result1(5>=result1(:, 4), :); B = result2(5>=result2(:, 4), :);  C = result3(5>=result3(:, 4), :);
Y_data = [A(:,9)';B(:,9)';C(:,9)'];%single
X= [A(:,4)';B(:,4)';C(:,4)'];
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.169,0.863,0.859 ];
lineStyles = {'-', '-', '-'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(X(i, :), Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('ratio', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left2, top_bottom, width, top_height]);
lgd = legend(lines, {'corner','long-border','short-border'}, 'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
hold off;
append_line_to_xlabel(gca, '(b) Variation in the ratio of single-movement with the shape factor of 1 to 5');

subplot(2, 2, 3);
Y_data = [result1(:,10)';result2(:,10)';result3(:,10)'];%block
X= [result1(:,4)';result2(:,4)';result3(:,4)'];
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.169,0.863,0.859 ];
lineStyles = {'-', '-', '-'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(X(i, :), Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('ratio', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left1, bot_bottom, width, bot_height]);
lgd = legend(lines, {'corner','long-border','short-border'}, 'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
hold off;
append_line_to_xlabel(gca, '(c) Variation in the ratio of block-movement across different I/O as a shape factor changes');

subplot(2, 2, 4);
A = result1(5>=result1(:, 4), :); B = result2(5>=result2(:, 4), :);  C = result3(5>=result3(:, 4), :);
Y_data = [A(:,10)';B(:,10)';C(:,10)'];%block
X= [A(:,4)';B(:,4)';C(:,4)'];
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.169,0.863,0.859 ];
lineStyles = {'-', '-', '-'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(X(i, :), Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('ratio', 'FontSize', sizexy, 'FontName', 'Times New Roman');%, 'FontWeight', 'bold'
set(gca, 'Position', [left2, bot_bottom, width, bot_height]);
lgd = legend(lines, {'corner','long-border','short-border'}, 'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
hold off;
append_line_to_xlabel(gca, '(d) Variation in the ratio of block-movement with the shape factor of 1 to 5');

exportgraphics(gcf, 'P12.png', 'Resolution', 600);
exportgraphics(gcf, 'P12.tiff', 'Resolution', 600, 'ContentType', 'image');
print(gcf, 'P12.eps',  '-depsc', '-vector', '-r600');





