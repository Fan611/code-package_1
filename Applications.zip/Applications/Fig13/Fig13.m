clear all;
clc;
legendsize=12;
sizexy_in=12;
load('sum_50_middle_single.mat');a1=sum_50_middle_single;
load('sum_50_middle_block.mat');b1=sum_50_middle_block;
load('sum_100_middle_single.mat');a2=sum_100_middle_single;
load('sum_100_middle_block.mat');b2=sum_100_middle_block;
load('sum_15_middle_single.mat');a3=sum_15_middle_single;
load('sum_15_middle_block.mat');b3=sum_15_middle_block;
load('sum_2_middle_single.mat');a4=sum_2_middle_single;
load('sum_2_middle_block.mat');b4=sum_2_middle_block;

fig = figure('Units', 'pixels', 'Position', [100, 100, 1100, 900], 'Color', 'w');
left1 = 0.04; left2 = 0.28;
left3=0.52;left4=0.76;
width = 0.2;
top_bottom = 0.57; top_height = 0.3;   
bot_bottom = 0.17; bot_height = 0.3;   
axisFontSize = 12;   
tu_size=12;
gap=-0.15;
xk=0.5;

ax1 = subplot(2,4,1);
a_sum=a1;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');%turbo
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);    
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
text(ax1, 0.5, gap, {'(a) Distribution of moves with a';'50×50 square under single-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left1, top_bottom, width, top_height]);

ax1 = subplot(2,4,2);
a_sum=a2;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);      
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
xtickangle(0);
text(ax1, 0.5, gap, {'(b) Distribution of moves with a';'100×100 square under single-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left2, top_bottom, width, top_height]);

ax1 = subplot(2,4,3);
a_sum=a3;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);    
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
text(ax1, 0.5, gap-0.33, {'(c) Distribution of moves with a';'shape factor of  1.5 under single-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left3, top_bottom, width, top_height]);

ax1 = subplot(2,4,4);
a_sum=a4;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);      
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
xtickangle(0);
text(ax1, 0.5, gap-0.65, {'(d) Distribution of moves with a';'shape factor of  2 under single-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left4, top_bottom, width, top_height]);

ax1 = subplot(2,4,5);
a_sum=b1;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...  
                  'LineWidth', xk);      
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
text(ax1, 0.5, gap, {'(e) Distribution of  moves with a';'50×50 square under blok-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left1, bot_bottom, width, bot_height]);

ax1 = subplot(2,4,6);
a_sum=b2;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);      
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
xtickangle(0);
text(ax1, 0.5, gap, {'(f) Distribution of moves with a';'100×100 square under block-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left2, bot_bottom, width, bot_height]);

ax1 = subplot(2,4,7);
a_sum=b3;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...   
                  'LineWidth', xk);     
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
xtickangle(0);
text(ax1, 0.5, gap-0.325, {'(g) Distribution of moves with a';'shape factor of  1.5 under block-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left3, bot_bottom, width, bot_height]);

ax1 = subplot(2,4,8);
a_sum=b4;
imagesc(ax1, a_sum);
axis(ax1, 'equal', 'tight');
colormap(ax1, 'parula');
set(ax1, 'YDir', 'normal');
hold(ax1, 'on');
cLimits = caxis(ax1);
cmin = cLimits(1); cmax = cLimits(2);
rangeVal = cmax - cmin;
targetN = 5;
rawStep = rangeVal / (targetN - 1 + eps);
mag = 10^floor(log10(rawStep));
normStep = rawStep / mag;
if      normStep <= 1, niceNormStep = 1;
elseif  normStep <= 2, niceNormStep = 2;
elseif  normStep <= 5, niceNormStep = 5;
else,   niceNormStep = 10;
end
step = niceNormStep * mag;
startTick = ceil(cmin / step) * step;
endTick   = floor(cmax / step) * step;
ticks = startTick:step:endTick;
if numel(ticks) < 2
    ticks = [floor(cmin), ceil(cmax)];
end
[~, hC] = contour(ax1, a_sum, ticks, ...   
                  'LineColor', 'k', ...  
                  'LineWidth', xk ...
                  );      
hold(ax1, 'off');
cb1 = colorbar(ax1, 'northoutside');
set(cb1, 'Ticks', ticks);
set(cb1, 'TickLabels', arrayfun(@(x) sprintf('%.0f', x), ticks, 'UniformOutput', false));
caxis(ax1, [ticks(1), ticks(end)]);
[Ny, Nx] = size(a_sum);
xTickStep = 10;
yTickStep = 10;
set(ax1, 'FontName', 'Times New Roman', 'XTick', 0:xTickStep:Nx);
set(ax1, 'FontName', 'Times New Roman', 'YTick', 0:yTickStep:Ny);
set(ax1, 'XTickLabel', arrayfun(@(x) sprintf('%.0f', x), get(ax1,'XTick'),'UniformOutput',false));
set(ax1, 'YTickLabel', arrayfun(@(y) sprintf('%.0f', y), get(ax1,'YTick'),'UniformOutput',false));
set(ax1, 'FontSize', axisFontSize);
xtickangle(0);
text(ax1, 0.5, gap-0.65, {'(h) Distribution of moves with a';'shape factor of  2 under block-move'}, ...
     'Units', 'normalized', ...
     'HorizontalAlignment', 'center', ...
     'VerticalAlignment', 'top', ...
     'FontSize', tu_size, 'FontName', 'Times New Roman');
dcm = datacursormode(gcf);
set(dcm, 'UpdateFcn', @(obj, event) myUpdateFcn(event));
set(gca, 'Position', [left4, bot_bottom, width, bot_height]);

exportgraphics(gcf, 'P13.png', 'Resolution', 600);
exportgraphics(gcf, 'P13.tiff', 'Resolution', 600, 'ContentType', 'image');
print(gcf, 'P13.eps',  '-depsc', '-vector', '-r600');
