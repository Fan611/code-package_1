function violins = violinplot(data, cats, varargin)

hascategories = exist('cats','var') && not(isempty(cats));

grouporder = {};
idx=find(strcmp(varargin, 'GroupOrder'));
if ~isempty(idx) && numel(varargin)>idx
    if iscell(varargin{idx+1})
        grouporder = varargin{idx+1};
        varargin(idx:idx+1)=[];
    else
        error('Second argument of ''GroupOrder'' optional arg must be a cell of category names')
    end
end

idx=find(strcmp(varargin, 'ViolinColor'));
if ~isempty(idx) && iscell(varargin{idx+1})
    if length(varargin{idx+1}(:))>2
        error('ViolinColor input can be at most a two element cell array');
    end
elseif ~isempty(idx) && isnumeric(varargin{idx+1})
    varargin{idx+1} = varargin(idx+1);
end

idx=find(strcmp(varargin, 'ViolinAlpha'));
if ~isempty(idx) && iscell(varargin{idx+1})
    if length(varargin{idx+1}(:))>2
        error('ViolinAlpha input can be at most a two element cell array');
    end
elseif ~isempty(idx) && isnumeric(varargin{idx+1})
    varargin{idx+1} = varargin(idx+1);
end

if isa(data, 'dataset') || isstruct(data) || istable(data)
    if isa(data, 'dataset')
        colnames = data.Properties.VarNames;
    elseif istable(data)
        colnames = data.Properties.VariableNames;
    elseif isstruct(data)
        colnames = fieldnames(data);
    end
    catnames = {};
    if isempty(grouporder)
        for n=1:length(colnames)
            if isnumeric(data.(colnames{n}))
                catnames = [catnames colnames{n}]; 
            end
        end
        catnames = sort(catnames);
    else
        for n=1:length(grouporder)
            if isnumeric(data.(grouporder{n}))
                catnames = [catnames grouporder{n}];
            end
        end
    end
    
    for n=1:length(catnames)
        thisData = data.(catnames{n});
        violins(n) = Violin({thisData}, n, varargin{:});
    end
    if strcmp(violins(1).Orientation,'vertical')
        set(violins(1).Parent, 'XTick', 1:length(catnames), 'XTickLabels', catnames);
    else
        set(violins(1).Parent, 'YTick', 1:length(catnames), 'YTickLabels', catnames);
    end
    set(violins(1).Parent,'Box','on');
    return
elseif iscell(data) && length(data(:))==2 
    if not(size(data{1},2)==size(data{2},2))
        error('The two input data matrices have to have the same number of columns');
    end
elseif iscell(data) && length(data(:))>2 
    error('Up to two datasets can be compared');
elseif isnumeric(data)  
    if hascategories && numel(data) == numel(cats)    
        if isempty(grouporder)
            cats = categorical(cats);
        else
            cats = categorical(cats, grouporder);
        end
        catnames = (unique(cats)); 
        catnames_labels = {};
        for n = 1:length(catnames)
            thisCat = catnames(n);
            catnames_labels{n} = char(thisCat);
            thisData = data(cats == thisCat);
            violins(n) = Violin({thisData}, n, varargin{:});
        end
        if strcmp(violins(1).Orientation,'vertical')
            set(violins(1).Parent, 'XTick', 1:length(catnames), 'XTickLabels', catnames);
        else
            set(violins(1).Parent, 'YTick', 1:length(catnames), 'YTickLabels', catnames);
        end
        set(violins(1).Parent,'Box','on');
        return
    else
        data = {data};
    end
end

if not(hascategories) && isvector(data{1})
    violins = Violin(data, 1, varargin{:});
    if strcmp(violins(1).Orientation,'vertical')
        set(violins(1).Parent, 'XTick', 1);
    else
        set(violins(1).Parent, 'yTick', 1);
    end
elseif ismatrix(data{1})
    for n=1:size(data{1}, 2)
        thisData = cellfun(@(x)x(:,n),data,'UniformOutput',false);
        violins(n) = Violin(thisData, n, varargin{:});
    end
    if strcmp(violins(1).Orientation,'vertical')
        set(violins(1).Parent, 'XTick', 1:size(data{1}, 2));
    else
        set(violins(1).Parent, 'YTick', 1:size(data{1}, 2));
    end
    if hascategories && length(cats) == size(data{1}, 2)
        if strcmp(violins(1).Orientation,'vertical')
            set(violins(1).Parent, 'XTickLabels', cats);
        else
            set(violins(1).Parent, 'YTickLabels', cats);
        end
    end
end
set(violins(1).Parent,'Box','on');
end
