clear all; clc;
load('single_total_1.mat');load('single_total_2.mat');load('single_total_3.mat');load('single_total_4.mat');load('single_total_5.mat');
load('single_total_6.mat');load('single_total_7.mat');load('single_total_8.mat');load('single_total_9.mat');load('single_total_10.mat');
load('single_s_total_1.mat');load('single_s_total_2.mat');load('single_s_total_3.mat');load('single_s_total_4.mat');load('single_s_total_5.mat');
load('single_s_total_6.mat');load('single_s_total_7.mat');load('single_s_total_8.mat');load('single_s_total_9.mat');load('single_s_total_10.mat');
load('total_1.mat');load('total_2.mat');load('total_3.mat');load('total_4.mat');load('total_5.mat');
load('total_6.mat');load('total_7.mat');load('total_8.mat');load('total_9.mat');load('total_10.mat');
load('s_total_1.mat');load('s_total_2.mat');load('s_total_3.mat');load('s_total_4.mat');load('s_total_5.mat');
load('s_total_6.mat');load('s_total_7.mat');load('s_total_8.mat');load('s_total_9.mat');load('s_total_10.mat');
signle_s_move=[single_s_total_1',single_s_total_2',single_s_total_3',single_s_total_4',single_s_total_5',single_s_total_6',single_s_total_7',single_s_total_8',single_s_total_9',single_s_total_10'];
signle_us_move=[single_total_1',single_total_2',single_total_3',single_total_4',single_total_5',single_total_6',single_total_7',single_total_8',single_total_9',single_total_10'];
block_s_move=[total_1',total_2',total_3',total_4',total_5',total_6',total_7',total_8',total_9',total_10'];
block_us_move=[s_total_1',s_total_2',s_total_3',s_total_4',s_total_5',s_total_6',s_total_7',s_total_8',s_total_9',s_total_10'];
clear single_s_total_1 single_s_total_2 single_s_total_3 single_s_total_4 single_s_total_5 single_s_total_6 single_s_total_7 single_s_total_8 single_s_total_9 single_s_total_10
clear single_total_1 single_total_2 single_total_3 single_total_4 single_total_5 single_total_6 single_total_7 single_total_8 single_total_9 single_total_10
clear s_total_1 s_total_2 s_total_3 s_total_4 s_total_5 s_total_6 s_total_7 s_total_8 s_total_9 s_total_10
clear total_1 total_2 total_3 total_4 total_5 total_6 total_7 total_8 total_9 total_10
z1=signle_s_move;
z2=signle_us_move;
z3=block_s_move;
z4=block_us_move;
clear signle_s_move signle_us_move block_s_move block_us_move
x = repmat(1:10, 10, 1); 
left1 = 0.08; 
left2 = 0.53;
width = 0.4;
dis=0.03;
top_height = 0.20;
bot_height = 0.10;
bot_bottom1 = 0.1;  
bot_bottom2 = bot_bottom1+top_height+dis; 
top_bottom2 = bot_bottom2+bot_height+0.08;
top_bottom1 = top_bottom2+top_height+dis;   
sizexy=10;
legendsize=10;
sizexy_in=10;
annHeight=0.04;
gap=0.001;

fig = figure('Units', 'pixels', 'Position', [100, 100, 1100, 900], 'Color', 'w');

subplot(4, 2, 1);
bar_color = [0.15, 0.50, 0.80]; 
bar(mean(z1, 1), 0.4, 'FaceColor', bar_color, 'EdgeColor', bar_color, 'LineWidth', 0.5);
xticks(1:1:10); 
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1.0'};
xticklabels(labels);
xtickangle(0); 
xlim([0.5 10.5]); 
ylim([77 81]); 
yticks(77:81); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('average number of moves', 'FontName','Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, top_bottom1, width, bot_height]);

subplot(4, 2, 3);
Y = z1;
violins = violinplot(Y);
box on;
xticks(1:1:10);
xticklabels(labels);
xlim([0.5 10.5]);    
ylim([0 160]); 
set(gca, 'FontSize', sizexy, 'FontName', 'Times New Roman'); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', arrayfun(@num2str, yt, 'UniformOutput', false), ...
    'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, top_bottom2, width, top_height]);
append_line_to_xlabel(gca, '(a) Moves of per grid unit in single-move under square layout');
subplot(4, 2, 2);
bar_color = [0.15, 0.50, 0.80]; 
bar(mean(z2, 1), 0.4, 'FaceColor', bar_color, 'EdgeColor', bar_color, 'LineWidth', 0.5);
xticks(1:1:10); 
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1.0'};
xticklabels(labels);
xtickangle(0); 
xlim([0.5 10.5]); 
ylim([106 111]); 
yticks(106:111); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('average number of moves', 'FontName','Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left2, top_bottom1, width, bot_height]);

subplot(4, 2, 4);
Y=z2;
violins = violinplot(Y);
 box on;
xticks(1:1:10);
xticklabels(labels);
xlim([0.5 10.5]);   
ylim([0 210]); 
set(gca, 'FontSize', sizexy, 'FontName', 'Times New Roman'); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', arrayfun(@num2str, yt, 'UniformOutput', false), ...
    'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left2, top_bottom2, width, top_height]);
append_line_to_xlabel(gca, '(b) Moves of per grid unit in a single-move under a layout with shape factor 2');

subplot(4, 2, 5);
bar_color = [0.15, 0.50, 0.80];
bar(mean(z3, 1), 0.4, 'FaceColor', bar_color, 'EdgeColor', bar_color, 'LineWidth', 0.5);
xticks(1:1:10); 
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1.0'};
xticklabels(labels);
xtickangle(0); 
xlim([0.5 10.5]); 
ylim([44 50]); 
yticks(44:50); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('average number of moves', 'FontName','Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, bot_bottom2, width, bot_height]);

subplot(4, 2, 7);
Y=z3;
violins = violinplot(Y);
 box on;
xticks(1:1:10);
xticklabels(labels);
xlim([0.5 10.5]);    
ylim([0 100]); 
set(gca, 'FontSize', sizexy, 'FontName', 'Times New Roman'); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', arrayfun(@num2str, yt, 'UniformOutput', false), ...
    'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, bot_bottom1, width, top_height]);
append_line_to_xlabel(gca, '(c) Moves of per grid unit in block-move under square layout');

subplot(4, 2, 6);
bar_color = [0.15, 0.50, 0.80];  
bar(mean(z4, 1), 0.4, 'FaceColor', bar_color, 'EdgeColor', bar_color, 'LineWidth', 0.5);
xticks(1:1:10); 
ylim([35 41]); 
yticks(35:41); 
labels = {'0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1.0'};
xticklabels(labels);
xtickangle(0); 
xlim([0.5 10.5]); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('average number of moves', 'FontName','Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left2, bot_bottom2, width, bot_height]);

subplot(4, 2, 8);
Y=z4;
violins = violinplot(Y);
 box on;
xticks(1:1:10);
xticklabels(labels);
xlim([0.5 10.5]);    
ylim([0 80]); 
set(gca, 'FontSize', sizexy, 'FontName', 'Times New Roman'); 
set(gca, 'XTickLabel', labels, 'FontSize', sizexy, 'FontName', 'Times New Roman');
yt = get(gca, 'YTick');
set(gca, 'YTick', yt, 'YTickLabel', arrayfun(@num2str, yt, 'UniformOutput', false), ...
    'FontSize', sizexy, 'FontName', 'Times New Roman');
ylabel('number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left2, bot_bottom1, width, top_height]);
append_line_to_xlabel(gca, '(d) Moves of per grid unit in a block-move under a layout with shape factor 2');
hold off;

exportgraphics(gcf, 'P11.png', 'Resolution', 600);
exportgraphics(gcf, 'P11.tiff', 'Resolution', 600, 'ContentType', 'image');
print(gcf, 'P11.eps',  '-depsc', '-vector', '-r600');







