function append_line_to_xlabel(ax, extraText)

    hx = get(ax, 'XLabel');
    s0 = get(hx, 'String');
    if isstring(s0); s0 = cellstr(s0); end
    if ischar(s0);   s0 = {s0};        end
    if isempty(s0);  s0 = {''};        end
    ud = get(hx, 'UserData');
    if isstruct(ud)
        if isfield(ud,'shiftApplied') && ud.shiftApplied ~= 0
            oldUnits = get(hx,'Units');
            set(hx,'Units','normalized');
            curPos = get(hx,'Position');
            set(hx,'Position',[curPos(1), curPos(2)-ud.shiftApplied, curPos(3)]);
            set(hx,'Units',oldUnits);
        end
         if isfield(ud,'appendedN') && ud.appendedN > 0
            n = ud.appendedN;
            if numel(s0) >= n
                s0(end-n+1:end) = [];
            else
                s0 = {};
            end
        end
    end

    wrapped = local_wrap_to_axes_width(ax, hx, char(extraText));
    newLines = [s0(:); wrapped(:)];
    set(hx, 'String',     newLines,          ...
            'FontName',   'Times New Roman',  ...
            'FontWeight', 'normal',           ...
            'Interpreter','none',             ...
            'FontSize',   10);
    nAppended    = numel(wrapped);
    shiftApplied = 0;
    if nAppended > 1
        drawnow('nocallbacks');              
        oldUnits = get(hx,'Units');
        set(hx,'Units','normalized');
        ext        = get(hx,'Extent');                        
        lineHeight = ext(4) / max(numel(newLines), 1);        
        shiftApplied = lineHeight * (nAppended - 1) * 0.6;   
        curPos = get(hx,'Position');
        set(hx,'Position',[curPos(1), curPos(2) + shiftApplied, curPos(3)]);
        set(hx,'Units', oldUnits);
    end
    ud2              = struct();
    ud2.appendedN    = nAppended;
    ud2.shiftApplied = shiftApplied;   
    set(hx, 'UserData', ud2);
end

function lines = local_wrap_to_axes_width(ax, hx, txt)
    oldAxUnits = get(ax,'Units');
    set(ax,'Units','pixels');
    axPos = get(ax,'Position');
    set(ax,'Units',oldAxUnits);
    maxWidth = axPos(3) * 0.95;
    if maxWidth <= 10
        lines = {txt};
        return;
    end
    t = text(ax, 0, 0, '', ...
        'Units','pixels', ...
        'Visible','off', ...
        'Interpreter','none', ...
        'FontName', get(hx,'FontName'), ...
        'FontWeight', get(hx,'FontWeight'), ...
        'FontSize', get(hx,'FontSize'));
    words = regexp(strtrim(txt), '\s+', 'split');
    if isempty(words) || (numel(words)==1 && isempty(words{1}))
        delete(t);
        lines = {''};
        return;
    end
    lines = {};
    cur = '';
    for i = 1:numel(words)
        w = words{i};
        if isempty(cur)
            candidate = w;
        else
            candidate = [cur ' ' w];
        end
        set(t, 'String', candidate);
        ext = get(t, 'Extent');   
        if ext(3) <= maxWidth
            cur = candidate;
        else
               if ~isempty(cur)
                lines{end+1,1} = cur; %
                cur = w;
            else
                [chunk, rest] = local_break_long_token(t, w, maxWidth);
                lines{end+1,1} = chunk; 
                cur = rest;
            end
        end
    end
    if ~isempty(cur)
        lines{end+1,1} = cur;
    end

    delete(t);
end

function [chunk, rest] = local_break_long_token(t, token, maxWidth)
    if isempty(token)
        chunk = '';
        rest  = '';
        return;
    end
    lo = 1; 
    hi = numel(token);
    best = 1;
    while lo <= hi
        mid = floor((lo+hi)/2);
        set(t,'String', token(1:mid));
        ext = get(t,'Extent');
        if ext(3) <= maxWidth
            best = mid;
            lo = mid + 1;
        else
            hi = mid - 1;
        end
    end
    chunk = token(1:best);
    rest  = strtrim(token(best+1:end));
end
