clear all;
clc;
sizexy=10;
legendsize=10;
sizexy_in=10;
load('single_total_100.mat');load('block_total_100.mat');
load('single_total_90.mat');load('block_total_90.mat');
load('single_total_80.mat');load('block_total_80.mat');
load('single_total_70.mat');load('block_total_70.mat');
load('single_total_60.mat');load('block_total_60.mat');
load('single_total_50.mat');load('block_total_50.mat');
load('single_total_40.mat');load('block_total_40.mat');
load('single_total_30.mat');load('block_total_30.mat');
load('single_total_20.mat');load('block_total_20.mat');
load('single_total_10.mat');load('block_total_10.mat');
a15=[single_total_10(:,6),single_total_20(:,6),single_total_30(:,6),single_total_40(:,6),single_total_50(:,6),single_total_60(:,6),single_total_70(:,6),single_total_80(:,6),single_total_90(:,6),single_total_100(:,6)];
a18=[single_total_10(:,9),single_total_20(:,9),single_total_30(:,9),single_total_40(:,9),single_total_50(:,9),single_total_60(:,9),single_total_70(:,9),single_total_80(:,9),single_total_90(:,9),single_total_100(:,9)];
a20=[single_total_10(:,end),single_total_20(:,end),single_total_30(:,end),single_total_40(:,end),single_total_50(:,end),single_total_60(:,end),single_total_70(:,end),single_total_80(:,end),single_total_90(:,end),single_total_100(:,end)];
b15=[block_total_10(:,6),block_total_20(:,6),block_total_30(:,6),block_total_40(:,6),block_total_50(:,6),block_total_60(:,6),block_total_70(:,6),block_total_80(:,6),block_total_90(:,6),block_total_100(:,6)];
b18=[block_total_10(:,9),block_total_20(:,9),block_total_30(:,9),block_total_40(:,9),block_total_50(:,9),block_total_60(:,9),block_total_70(:,9),block_total_80(:,9),block_total_90(:,9),block_total_100(:,9)];
b20=[block_total_10(:,end),block_total_20(:,end),block_total_30(:,end),block_total_40(:,end),block_total_50(:,end),block_total_60(:,end),block_total_70(:,end),block_total_80(:,end),block_total_90(:,end),block_total_100(:,end)];
load('three_total.mat');
a_s=[three_total(1,:);three_total(3,:);three_total(5,:)];
b_s=[three_total(2,:);three_total(4,:);three_total(6,:)];

fig = figure('Units', 'pixels', 'Position', [100, 100, 1100, 900], 'Color', 'w');
x = 1:10;
left1 = 0.03; left2 = 0.28;
left3=0.53;left4=0.78;
width = 0.2;
top_bottom = 0.57; top_height = 0.30;   
bot_bottom = 0.15; bot_height = 0.30;   
sizexy=10;
legendsize=8;
sizexy_in=8;
annHeight=0.04;
gap=0.001;
subplot(2, 4, 1);
Y_data = a15;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×15','20×30','30×45','40×60','50×75','60×90','70×105','80×120','90×135','100×150'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, top_bottom, width, top_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(a) Movement for a layout shape factor of 1.5 under a single-move');

subplot(2, 4, 2);
Y_data = a18;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×18','20×36','30×54','40×72','50×90','60×108','70×126','80×144','90×162','100×180'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman',  'FontSize', sizexy);
set(gca, 'Position', [left2, top_bottom, width, top_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(b) Movement for a layout shape factor of 1.8 under a single-move');

subplot(2, 4, 3);
Y_data =a20;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);%旋转45°
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman',  'FontSize', sizexy);
set(gca, 'Position', [left3, top_bottom, width, top_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(c) Movement for a layout shape factor of 2 under a single-move');

subplot(2, 4, 4);
Y_data = a_s;
colors = [  0.2314,0.3255,0.5373;
    0.8941,0.1020,0.1098;
    0.0000,0.6275,0.5294];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);%旋转45°
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left4, top_bottom, width, top_height]);
lgd = legend(lines, {
    'same-side variant',
    'wide-boundary variant',
    'opposite-side variant'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(d) Movement for three variants layout shape factoe 2 under single-move');
hold off;

subplot(2, 4, 5);
Y_data = b15;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×15','20×30','30×45','40×60','50×75','60×90','70×105','80×120','90×135','100×150'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left1, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(e) Movement for a layout shape factor of 1.5 under a block-move');

subplot(2, 4, 6);
Y_data = b18;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×18','20×36','30×54','40×72','50×90','60×108','70×126','80×144','90×162','100×180'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman', 'FontSize', sizexy);
set(gca, 'Position', [left2, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(f)  Movement for a layout shape factor of 1.8 under a block-move');

subplot(2, 4, 7);
Y_data = b20;
colors = [   0, 0.4470, 0.7410;
    0.8500, 0.3250, 0.0980;
    0.4660, 0.6740, 0.1880];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);%旋转45°
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman',  'FontSize', sizexy);
set(gca, 'Position', [left3, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    'Proposal Ⅰ',
    'Proposal Ⅱ',
    'Proposal Ⅲ'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(g) Movement for a layout shape factor of 2 under a block-move');

subplot(2, 4, 8);
Y_data = b_s;
colors = [   0.2314,0.3255,0.5373;
    0.8941,0.1020,0.1098;
    0.0000,0.6275,0.5294];
markers = {'^', 's',  'o'};
lineStyles = {'-',  '--', '-.'};
hold on; box on;
lines = gobjects(3, 1);
for i = 1:3
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);%旋转45°
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontName', 'Times New Roman',  'FontSize', sizexy);
set(gca, 'Position', [left4, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    'same-side variant',
    'wide-boundary variant',
    'opposite-side variant'
}, 'Location', 'northwest',  'Interpreter', 'none','FontSize', legendsize);%, 'Interpreter', 'latex'
legend boxoff;
legend boxoff;
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(h) Movement for three variants layout shape factoe 2 under block-move');
hold off;

exportgraphics(gcf, 'P10.png', 'Resolution', 600);
exportgraphics(gcf, 'P10.tiff', 'Resolution', 600, 'ContentType', 'image');% TIFF（位图，无损）
print(gcf, 'P10.eps',  '-depsc', '-vector', '-r600');
