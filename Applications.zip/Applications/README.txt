1. The folder names correspond to the respective image numbers.
2. Run the corresponding image number in each folder to generate that image.
3. The experimental data required for each image is already included in the folder.
4. We recommend using MATLAB R2025a or later.