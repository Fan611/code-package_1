clear all;
clc;
a=zeros(5,10);a_dr=zeros(5,10);a_der=zeros(5,10);a_block=zeros(5,10);a_block_der=zeros(5,10);a_block_dr=zeros(5,10);
b=zeros(5,10);b_dr=zeros(5,10);b_der=zeros(5,10);b_block=zeros(5,10);b_block_der=zeros(5,10);b_block_dr=zeros(5,10);
counts = 1;
for H=10:10:100
    L = H; m=1;
    T=H*L-1;
    n = 1;
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    a(1,counts)=single_step/T;a_dr(1,counts)=acc_s/T;a_der(1,counts)=app_s/T;
    a_block(1,counts)=block_step/T;a_block_dr(1,counts)=acc_b/T;a_block_der(1,counts)=app_b/T;

    n = round(L/8);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    a(2,counts)=single_step/T;a_dr(2,counts)=acc_s/T;a_der(2,counts)=app_s/T;
    a_block(2,counts)=block_step/T;a_block_dr(2,counts)=acc_b/T;a_block_der(2,counts)=app_b/T;

    n = round(L/4);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    a(3,counts)=single_step/T;a_dr(3,counts)=acc_s/T;a_der(3,counts)=app_s/T;
    a_block(3,counts)=block_step/T;a_block_dr(3,counts)=acc_b/T;a_block_der(3,counts)=app_b/T;

    n = round(3*L/8);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    a(4,counts)=single_step/T;a_dr(4,counts)=acc_s/T;a_der(4,counts)=app_s/T;
    a_block(4,counts)=block_step/T;a_block_dr(4,counts)=acc_b/T;a_block_der(4,counts)=app_b/T;

    n = round(L/2);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    a(5,counts)=single_step/T;a_dr(5,counts)=acc_s/T;a_der(5,counts)=app_s/T;
    a_block(5,counts)=block_step/T;a_block_dr(5,counts)=acc_b/T;a_block_der(5,counts)=app_b/T;

    counts = counts + 1;
end


counts = 1;
for H=10:10:100
    L = 2* H; m=1;
    T=H*L-1;
    n = 1;
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    b(3,counts)=single_step/T;b_dr(3,counts)=acc_s/T;b_der(3,counts)=app_s/T;
    b_block(3,counts)=block_step/T;b_block_dr(3,counts)=acc_b/T;b_block_der(3,counts)=app_b/T;

    n = round(L/4);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    b(4,counts)=single_step/T;b_dr(4,counts)=acc_s/T;b_der(4,counts)=app_s/T;
    b_block(4,counts)=block_step/T;b_block_dr(4,counts)=acc_b/T;b_block_der(4,counts)=app_b/T;

    n = round(L/2);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    b(5,counts)=single_step/T;b_dr(5,counts)=acc_s/T;b_der(5,counts)=app_s/T;
    b_block(5,counts)=block_step/T;b_block_dr(5,counts)=acc_b/T;b_block_der(5,counts)=app_b/T;

    counts = counts + 1;
end

counts = 1;
for H=20:20:200
    L =H/2; m=1;
    T=H*L-1;
    n = round(L/4);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    b(1,counts)=single_step/T;b_dr(1,counts)=acc_s/T;b_der(1,counts)=app_s/T;
    b_block(1,counts)=block_step/T;b_block_dr(1,counts)=acc_b/T;b_block_der(1,counts)=app_b/T;

    n = round(L/2);
    [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n);
    b(2,counts)=single_step/T;b_dr(2,counts)=acc_s/T;b_der(2,counts)=app_s/T;
    b_block(2,counts)=block_step/T;b_block_dr(2,counts)=acc_b/T;b_block_der(2,counts)=app_b/T;

    counts = counts + 1;
end

max_value_a=max(max([a,a_block]));
min_value_a=min(max([a,a_block]));
max_value_b=max(max([b,b_block]));
min_value_b=min(max([b,b_block]));
x_min=0.95;
x_max=1.05;
for i=1:size(a,1)
    for j=1:size(a,2)
        a_all_bit(i,j)=(a(i,j)-a_block(i,j))/a(i,j);
        a_dr_bit(i,j)=(a_dr(i,j)-a_block_dr(i,j))/a_dr(i,j);
        a_der_bit(i,j)=(a_der(i,j)-a_block_der(i,j))/a_der(i,j);
    end
end
for i=1:size(b,1)
    for j=1:size(b,2)
        b_all_bit(i,j)=(b(i,j)-b_block(i,j))/b(i,j);
        b_dr_bit(i,j)=(b_dr(i,j)-b_block_dr(i,j))/b_dr(i,j);
        b_der_bit(i,j)=(b_der(i,j)-b_block_der(i,j))/b_der(i,j);
    end
end
for i=1:size(a,1)
    for j=1:size(a,2)
        sam=(a(i,j)-a_block(i,j));
        a_der_bit2(i,j)=(a_der(i,j)-a_block_der(i,j))/sam;
        a_dr_bit2(i,j)=(a_dr(i,j)-a_block_dr(i,j))/sam;
    end
end
for i=1:size(b,1)
    for j=1:size(b,2)
        sam=(b(i,j)-b_block(i,j));
        b_der_bit2(i,j)=(b_der(i,j)-b_block_der(i,j))/sam;
        b_dr_bit2(i,j)=(b_dr(i,j)-b_block_dr(i,j))/sam;
    end
end

fig = figure('Units', 'pixels', 'Position', [100, 100, 1100, 900], 'Color', 'w');
x = 1:10;
function place_below_xlabel(ax, txt, annHeight, gap)
    if nargin < 3 || isempty(annHeight); annHeight = 0.04; end
    if nargin < 4 || isempty(gap); gap = 0.01; end
    origAxUnits = get(ax, 'Units');
    set(ax, 'Units', 'normalized');
    axPos = get(ax, 'position'); 
    hx = get(ax, 'xlabel');
    origLabelUnits = get(hx, 'Units');
    set(hx, 'Units', 'normalized'); 
    labelExt = get(hx, 'Extent');   
    xlabel_bottom_fig = axPos(2) + axPos(4) * labelExt(2);
    annTop = xlabel_bottom_fig - gap;
    annBottom = annTop - annHeight;
    if annBottom < 0
        annBottom = 0;
        annTop = annBottom + annHeight;
        if annTop >= xlabel_bottom_fig
            annBottom = max(0, axPos(2) - 0.005);
            annTop = annBottom + annHeight;
        end
    end
    annLeft = axPos(1);
    annWidth = axPos(3);
    annotation('textbox', [annLeft, annBottom, annWidth, annHeight], ...
        'String', txt, ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'FontSize', 10, ...
        'FontWeight', 'bold', ...
        'EdgeColor', 'none', ...
        'Interpreter', 'none');
    set(hx, 'Units', origLabelUnits);
    set(ax, 'Units', origAxUnits);
end

left1 = 0.03; left2 = 0.28;
left3=0.53;left4=0.78;
width = 0.2;
top_bottom = 0.57; top_height = 0.30;   
bot_bottom = 0.15; bot_height = 0.30;   
sizexy=10;
legendsize=10;
sizexy_in=10;
annHeight=0.02;
gap=0.001;

subplot(2, 4, 1);
Y_data = a;
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.906,0.549,0.302;
    0.459,0.651,0.282;
    0.169,0.863,0.859 ];
markers = {'^', 's', 'd', 'o', 'v'};
lineStyles = {'-', '-.', '--', '-.', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×10','20×20','30×30','40×40','50×50','60×60','70×70','80×80','90×90','100×100'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left1, top_bottom, width, top_height]);
lgd = legend(lines, {
        '$$\mathrm{1}\ \mathrm{or}\ l$$',
    '$$l/\mathrm{8}$$',
    '$$l/\mathrm{4}$$',
    '$$\mathrm{3}l/\mathrm{8}$$',
    '$$l/\mathrm{2}$$'}, ...
    'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
ylim([min_value_a*x_min, max_value_a*x_max]);
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(a) Movement with various I/O locations for square grid under single-move');

subplot(2, 4, 2);
Y_data = a_block;
colors = [  0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.906,0.549,0.302;
    0.459,0.651,0.282;
    0.169,0.863,0.859];
markers = {'^', 's', 'd', 'o', 'v'};
lineStyles = {'-', '-.', '--', '-.', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×10','20×20','30×30','40×40','50×50','60×60','70×70','80×80','90×90','100×100',};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left2, top_bottom, width, top_height]);
lgd = legend(lines, {
        '$$\mathrm{1}\ \mathrm{or}\ l$$',
    '$$l/\mathrm{8}$$',
    '$$l/\mathrm{4}$$',
    '$$\mathrm{3}l/\mathrm{8}$$',
    '$$l/\mathrm{2}$$'}, ...
    'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
ylim([min_value_a*x_min, max_value_a*x_max]);
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(b) Movement with various I/O locations for square grid under block-move');

subplot(2, 4, 3);
Y_data = a_all_bit;
colors = [   0.004,0.514,0.965;
    0.890, 0.439, 0.890;
    0.906,0.549,0.302;
    0.459,0.651,0.282;
    0.169,0.863,0.859 ];
markers = {'^', 's', 'd', 'o', 'v'};
lineStyles = {'-', '-.', '--', '-.', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×10','20×20','30×30','40×40','50×50','60×60','70×70','80×80','90×90','100×100', 'FontSize', sizexy_in};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('reduction percentage', 'FontSize', sizexy);
set(gca, 'Position', [left3, top_bottom, width, top_height]);
lgd = legend(lines, {
    '$$\mathrm{1}\ \mathrm{or}\ l$$',
    '$$l/\mathrm{8}$$',
    '$$l/\mathrm{4}$$',
    '$$\mathrm{3}l/\mathrm{8}$$',
    '$$l/\mathrm{2}$$'
}, 'Location', 'southeast', 'Interpreter', 'latex', 'FontSize', legendsize);
legend boxoff;
xlim([1 10]);
yt = get(gca, 'YTick'); 
yt_labels = arrayfun(@(v) sprintf('%.0f%%', v*100), yt, 'UniformOutput', false);  
set(gca, 'YTickLabel', yt_labels);
hold off;
append_line_to_xlabel(gca, '(c) Reduction proportion of block-move at different I/O ports under square grid');

subplot(2, 4, 4);
categories = {'10×10','20×20','30×30','40×40','50×50','60×60','70×70','80×80','90×90','100×100'};
data_upper_mean = mean(a_der_bit,1);      % 对应 0~100%
data_upper_min  = min(a_der_bit, [], 1);
data_upper_max  = max(a_der_bit, [], 1);
data_lower_mean = mean(a_dr_bit,1);       % 对应 0~20%（即 0~0.2）
data_lower_min  = min(a_dr_bit, [], 1);
data_lower_max  = max(a_dr_bit, [], 1);
err_upper_pos = data_upper_max - data_upper_mean;
err_upper_neg = data_upper_mean - data_upper_min;
err_lower_pos = data_lower_max - data_lower_mean;
err_lower_neg = data_lower_mean - data_lower_min;
data_upper_plot     = data_upper_mean;
err_upper_pos_plot  = err_upper_pos;
err_upper_neg_plot  = err_upper_neg;
data_lower_plot     = -data_lower_mean;
err_lower_pos_plot  = err_lower_pos;
err_lower_neg_plot  = err_lower_neg;
hold on;
x = 1:10;
b1 = bar(x, mean(a_der_bit2,1), 0.6, 'FaceColor', [0.64, 0.83, 0.94]);
hold on;   
b3 = plot(x,data_upper_plot , '-o', ...
    'Color', [0.10 0.45 0.70], 'LineWidth', 1.8, ...
    'MarkerSize', 5, 'MarkerFaceColor', [0.10 0.45 0.70]);
b4 = plot(x, data_lower_plot, '-o', ...
    'Color', [0.10 0.20 0.35], 'LineWidth', 1.8, ...
    'MarkerSize', 5, 'MarkerFaceColor', [0.10 0.20 0.35]);
xticks(1:10);
xticklabels(labels);
xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2);
set(gca, 'XMinorTick', 'off', 'YMinorTick', 'off');
ylabel('proportion', 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylim([-0.2, 1]);
ax = gca;
yt = [-0.2 0 0.2 0.4 0.6 0.8 1.0];
ax.YTick = yt;
ytlbl = strings(size(yt));
for i = 1:numel(yt)
    if yt(i) > 0
        ytlbl(i) = sprintf('%.0f%%', yt(i) * 100);
    elseif yt(i) < 0
        ytlbl(i) = sprintf('%.0f%%', abs(yt(i)) * 100);
    else
        ytlbl(i) = '0';
    end
end
ax.YTickLabel = ytlbl;
yline(0, 'k-', 'LineWidth', 1);
set(gca, 'GridLineStyle', '-', 'GridAlpha', 0.3);
box on;
set(gcf, 'Color', 'w');
set(gca, 'Color', 'w');
[hleg, icons] = legend([b1, b3, b4], {'approaching moves in total', 'reduction of approaching', 'reduction of accompanying'}, ...
    'Location', 'northeast', ...
    'Box', 'off', ...
    'FontSize', sizexy_in, 'FontName','Times New Roman');
set(hleg, 'ItemTokenSize', [2, 2]);
set(hleg, 'Units', 'normalized');      
pos = get(hleg, 'Position');           
dx = -0.06;                            
dy = 0.07;                            
pos(1) = pos(1) - dx;                  
pos(2) = pos(2) - dy;                  
set(hleg, 'Position', pos);
hold off;
set(gca, 'Position', [left4, top_bottom, width, top_height]);
xlim([0.5, 10.5]);
append_line_to_xlabel(gca, '(d) Block-move effects on approaching and accompanying movement under square grid');
hold off;

subplot(2, 4, 5);
Y_data = b;
colors = [    0.690, 0.280, 0.690;
    0.20, 0.40, 0.10;
    0.004,0.514,0.965;
    0.906,0.549,0.302;
    0.169,0.863,0.859];
markers = {'s', 'o', '^', 'd', 'v'};
lineStyles = {'-.', '-.', '-', '--', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200', 'FontSize', sizexy_in};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left1, bot_bottom, width, bot_height]);
lgd = legend(lines, {
'$$h/\mathrm{4}$$', '$$h/\mathrm{2}$$', '$$\mathrm{1}\ \mathrm{or}\ l$$', '$$l/\mathrm{4}$$','$$l/\mathrm{2}$$'}, ...
'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
ylim([min_value_b*x_min, max_value_b*x_max]);
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(e) Movement with various I/O locations for rectangular grid under single-move');

subplot(2, 4, 6);
Y_data = b_block;
colors = [   0.690, 0.280, 0.690;
    0.20, 0.40, 0.10;
    0.004,0.514,0.965;
    0.906,0.549,0.302;
    0.169,0.863,0.859 ];
markers = {'s', 'o', '^', 'd', 'v'};
lineStyles = {'-.', '-.', '-', '--', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200', 'FontSize', sizexy_in};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('average number of moves', 'FontSize', sizexy, 'FontName', 'Times New Roman');
set(gca, 'Position', [left2, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    '$$h/\mathrm{4}$$', '$$h/\mathrm{2}$$', '$$\mathrm{1}\ \mathrm{or}\ l$$', '$$l/\mathrm{4}$$','$$l/\mathrm{2}$$'}, ...
    'Location', 'northwest', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
ylim([min_value_b*x_min, max_value_b*x_max]);
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(f) Movement with various I/O locations for rectangular grid under block-move');

subplot(2, 4, 7);
Y_data = b_all_bit;
colors = [   0.690, 0.280, 0.690;
    0.20, 0.40, 0.10;
    0.004,0.514,0.965;
    0.906,0.549,0.302;
    0.169,0.863,0.859 ];
markers = {'s', 'o', '^', 'd', 'v'};
lineStyles = {'-.', '-.', '-', '--', '-'};
hold on; box on;
lines = gobjects(5, 1);
for i = 1:5
    lines(i) = plot(x, Y_data(i, :), ...
        'Color', colors(i, :), ...
        'LineStyle', lineStyles{i}, ...
        'LineWidth', 1.5, ...
        'Marker', markers{i}, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', colors(i, :), ...
        'MarkerFaceColor', colors(i, :));
end
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200'};
xticks(1:1:10); xticklabels(labels); xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2, 'GridAlpha', 0.15);
ylabel('reduction percentage', 'FontSize', sizexy, 'FontName', 'Times New Roman');%
set(gca, 'Position', [left3, bot_bottom, width, bot_height]);
lgd = legend(lines, {
    '$$h/\mathrm{4}$$', '$$h/\mathrm{2}$$', '$$\mathrm{1}\ \mathrm{or}\ l$$', '$$l/\mathrm{4}$$','$$l/\mathrm{2}$$'}, ...
    'Location', 'best', 'Interpreter', 'latex', 'FontSize', legendsize, 'FontName','Times New Roman');
legend boxoff;
yt = get(gca, 'YTick'); 
yt_labels = arrayfun(@(v) sprintf('%.0f%%', v*100), yt, 'UniformOutput', false);  
set(gca, 'YTickLabel', yt_labels);
xlim([1 10]);
hold off;
append_line_to_xlabel(gca, '(g) Reduction proportion of block-move at different I/O ports under rectangular grid');

subplot(2, 4, 8);
categories = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200', 'FontSize', sizexy_in};
data_upper_mean = mean(b_der_bit,1);      
data_upper_min  = min(b_der_bit, [], 1);
data_upper_max  = max(b_der_bit, [], 1);
data_lower_mean = mean(b_dr_bit,1);       
data_lower_min  = min(b_dr_bit, [], 1);
data_lower_max  = max(b_dr_bit, [], 1);
err_upper_pos = data_upper_max - data_upper_mean;
err_upper_neg = data_upper_mean - data_upper_min;
err_lower_pos = data_lower_max - data_lower_mean;
err_lower_neg = data_lower_mean - data_lower_min;
data_upper_plot     = data_upper_mean;
err_upper_pos_plot  = err_upper_pos;
err_upper_neg_plot  = err_upper_neg;
data_lower_plot     = -data_lower_mean;
err_lower_pos_plot  = err_lower_pos;
err_lower_neg_plot  = err_lower_neg;
hold on;
x = 1:10;
b1 = bar(x, mean(b_der_bit2,1), 0.6, 'FaceColor', [0.64, 0.83, 0.94]);
hold on;   
b3 = plot(x,data_upper_plot , '-o', ...
    'Color', [0.10 0.45 0.70], 'LineWidth', 1.8, ...
    'MarkerSize', 5, 'MarkerFaceColor', [0.10 0.45 0.70]);
b4 = plot(x, data_lower_plot, '-o', ...
    'Color', [0.10 0.20 0.35], 'LineWidth', 1.8, ...
    'MarkerSize', 5, 'MarkerFaceColor', [0.10 0.20 0.35]);
labels = {'10×20','20×40','30×60','40×80','50×100','60×120','70×140','80×160','90×180','100×200', 'FontSize', sizexy_in};
xticks(1:10);
xticklabels(labels);
xtickangle(45);
set(gca, 'FontName', 'Times New Roman', 'FontSize', sizexy_in, 'LineWidth', 1.2);
set(gca, 'XMinorTick', 'off', 'YMinorTick', 'off');
ylabel('proportion', 'FontSize', sizexy, 'FontName', 'Times New Roman');
ylim([-0.25, 1]);    
ax = gca;
yt = [-0.2 0 0.2 0.4 0.6 0.8 1.0];
ax.YTick = yt;
ytlbl = strings(size(yt));
for i = 1:numel(yt)
    if yt(i) > 0
        ytlbl(i) = sprintf('%.0f%%', yt(i) * 100);
    elseif yt(i) < 0

        ytlbl(i) = sprintf('%.0f%%', abs(yt(i)) * 100);  
    else
        ytlbl(i) = '0';
    end
end
ax.YTickLabel = ytlbl;
yline(0, 'k-', 'LineWidth', 1);
set(gca, 'GridLineStyle', '-', 'GridAlpha', 0.3);
box on;
set(gcf, 'Color', 'w');
set(gca, 'Color', 'w');
[hleg, icons] = legend([b1, b3, b4], {'approaching moves in total', 'reduction of approaching', 'reduction of accompanying'}, ...
    'Location', 'northeast', ...
    'Box', 'off', ...
    'FontSize', sizexy_in);
set(hleg, 'ItemTokenSize', [2, 2]);
set(hleg, 'Units', 'normalized');      
pos = get(hleg, 'Position');           
dx = -0.06;                             
dy = 0.02;                             
pos(1) = pos(1) - dx;                  
pos(2) = pos(2) - dy;                  
set(hleg, 'Position', pos);
set(gca, 'position', [left4, bot_bottom, width, bot_height]);
xlim([0.5, 10.5]);
append_line_to_xlabel(gca, '(h) Block-move effects on approaching and accompanying movement under rectangular grid');
hold off;

exportgraphics(gcf, 'P8.png', 'Resolution', 600);
exportgraphics(gcf, 'P8.tiff', 'Resolution', 600, 'ContentType', 'image');
print(gcf, 'P8.eps',  '-depsc', '-vector', '-r600');
