function place_below_xlabel(ax, extraText, annHeight, gap)
    if nargin < 3 || isempty(annHeight); annHeight = 0.04; end
    if nargin < 4 || isempty(gap); gap = 0.001; end
    fig = ancestor(ax,'figure');
    origAxUnits = get(ax,'Units');
    set(ax,'Units','normalized');
    axPos = get(ax,'Position'); 
    hx = get(ax,'XLabel');
    origHxUnits = get(hx,'Units');
    set(hx,'Units','normalized');
    gapAx = gap / axPos(4);
    annHeightAx = annHeight / axPos(4);
    ext0 = get(hx,'Extent');     
    yBottom0 = ext0(2);
    s0 = get(hx,'String');
    if isstring(s0); s0 = cellstr(s0); end
    if ischar(s0);   s0 = {s0}; end
    if isempty(s0);  s0 = {''}; end
    wrapWidthAx = 0.98; 
    extraLines = local_wordwrap_like_xlabel(ax, hx, extraText, wrapWidthAx);
    newLines = [s0(:); extraLines(:)];
    set(hx, 'String', newLines);
    drawnow; 
    ext1 = get(hx,'Extent');
    yBottom1 = ext1(2);
    yBottomDesired = yBottom0 - gapAx - annHeightAx;
    dy = yBottomDesired - yBottom1; 
    p = get(hx,'Position');
    set(hx,'Position', [p(1), p(2) + dy, p(3)]);
    set(hx,'Units',origHxUnits);
    set(ax,'Units',origAxUnits);
end

function lines = local_wordwrap_like_xlabel(ax, hx, txt, maxWidthAx)
    if isstring(txt); txt = char(txt); end
    txt = strtrim(txt);
    if isempty(txt)
        lines = {''};
        return;
    end
    props = { ...
        'FontName',   get(hx,'FontName'), ...
        'FontSize',   get(hx,'FontSize'), ...
        'FontWeight', get(hx,'FontWeight'), ...
        'FontAngle',  get(hx,'FontAngle'), ...
        'Interpreter',get(hx,'Interpreter')};
    hTmp = text(ax, 0, 0, '', ...
        'Units','normalized', ...
        'HorizontalAlignment','left', ...
        'VerticalAlignment','bottom', ...
        'Visible','off', ...
        'Clipping','off', props{:});
    words = regexp(txt, '\s+', 'split');
    cur = "";
    lines = {};
    for i = 1:numel(words)
        w = string(words{i});
        if strlength(cur) == 0
            cand = w;
        else
            cand = cur + " " + w;
        end
        set(hTmp,'String', char(cand));
        ext = get(hTmp,'Extent'); 
        if ext(3) <= maxWidthAx
            cur = cand;
        else
            if strlength(cur) == 0

                lines{end+1,1} = char(cand); 
                cur = "";
            else
                lines{end+1,1} = char(cur); 
                cur = w;
            end
        end
    end
    if strlength(cur) > 0
        lines{end+1,1} = char(cur);
    end
    delete(hTmp);
end
