function [single_step, block_step,acc_s,app_s,acc_b,app_b] = formulate_new_2(H,L, m, n)
if (m==1)&&(n==1)
    p=min(H,L);q=max(H,L);
    acc_s = p*(p-1)*(8*p+11)/12 + p*(p-1)*(2*q-1)/4 + 5*p*q*(q-1)/2 - 4*p*q + 2*(p+1);
else    
     p=min(H,n);q=max(H,n);
    temp1 = p*(p-1)*(8*p+11)/12 + p*(p-1)*(2*q-1)/4 + 5*p*q*(q-1)/2 - 4*p*q + 2*(p+1);
    p=min(H,L-n+1);q=max(H,L-n+1);
    temp2 = p*(p-1)*(8*p+11)/12 + p*(p-1)*(2*q-1)/4 + 5*p*q*(q-1)/2 - 4*p*q + 2*(p+1);
    p=min(H,1);q=max(H,1);
    temp3 = p*(p-1)*(8*p+11)/12 + p*(p-1)*(2*q-1)/4 + 5*p*q*(q-1)/2 - 4*p*q + 2*(p+1);
   acc_s = temp1+temp2-temp3;
end
if (m==1)&&(n==1)
    p=min(H,L);q=max(H,L);
    acc_b = p*q*(2*p+2*q-7)-p*(p-1)*(3*q-p-1)/3 +p+2;
else
     p=min(H,n);q=max(H,n);
    temp1 = p*q*(2*p+2*q-7)-p*(p-1)*(3*q-p-1)/3 +p+2;
    p=min(H,L-n+1);q=max(H,L-n+1);
    temp2 = p*q*(2*p+2*q-7)-p*(p-1)*(3*q-p-1)/3 +p+2;
    p=min(H,1);q=max(H,1);
    temp3 = p*q*(2*p+2*q-7)-p*(p-1)*(3*q-p-1)/3 +p+2;
   acc_b = temp1+temp2-temp3;
end
if (m==1)&&(n==1)
    s1=0;s2=0;s3=0;s4=0;
    if L>=(H-1)
        s1=((H^5)-2*(H^4)+(3*L*L-L+3)*(H^3)-(3*L*L-3*L+16)*(H^2)-(2*L-14)*H)/12;
    elseif (L-2)>=H
        s2=(4*L*L*H*H*H+(L*L-3*L+8)*L*(H^2)-(5*L*L+7*L+34)*H*L+(-L*L*L*L+2*L*L*L+5*L*L+16*L+14)*L)/12;
    end
    if H>=(L-1)
        s3=((L^5)-2*(L^4)+(3*H*H-H+3)*(L^3)-(3*H*H-3*H+16)*(L^2)-(2*H-14)*L)/12;
    elseif (L-2)>=H
        s4=(4*L*L*L*H*H+(H*H-3*H+8)*H*(L^2)-(5*H*H+7*H+34)*H*L+(-H*H*H*H+2*H*H*H+5*H*H+16*H+14)*H)/12;
    end
    p=min(H,L);
    temp5=(p-1)*(p*p*(H+L+2)/3 -p*(3*H*L+2*H+2*L+1)/3 +(H*L*(H+L)-2)/2);%i=j
    app_s = temp5 + s1+s2+s3+s4;
    app_s=app_s/(H*L-1);
else
     p=min(H,L);
     app_s = (H*H*L*L*(H+L) - H*L*(H+L))/3 - 0.5*H*L*(1-p)-2*(H+L)*(H*L-p+1);
     app_s=app_s/(H*L-1);
end
if (m==1)&&(n==1)
    p=min(H,L);
    s1=(L-1)*(H*L-2)*3/2;
    s2=(H-1)*(H*L-2)*3/2;
    p=min(H,L);
    s3=p*p*p/3 - (H+L+3)*p*p/2+ p*(2*H*L+0.5*(H+L)-5/6) - 2*H*L + 2;
    if (L+1)>=H
        s4=(H-1)*(H-2)*(4*H*L-H-9)/6;
    else
        s4=(L-1)*(9*L*H*H-6*L*L*H-12*H*L+L*L*L+3*L*L-18*H+11*L+18)/6;
    end
    if (H+1)>=L
        s5=(L-1)*(L-2)*(4*H*L-L-9)/6;
    else
        s5=(H-1)*(9*H*L*L-6*H*H*L-12*H*L+H*H*H+3*H*H-18*L+11*H+18)/6;
    end
    min_num=min(H,L);max_num=max(H,L);
    k1=min_num*(min_num-1)*(min_num-2)/6;
    k2=(min_num-1)*min_num/2;
    num = 2*k1 + (max_num-min_num)*k2;
    app_b = s1+s2+s3+s4+s5-num;
    app_b=app_b/(H*L-1);
else
     p=min(H,L);
     app_b=(p-1)*(p*(H+L+p+1)+2*p*(H*L-1))/(H*L)+(H*L-p+1)/(2*H-1);
     app_b=app_b/(H*L-1);
end
single_step=acc_s+app_s;
block_step=acc_b+app_b;
end
